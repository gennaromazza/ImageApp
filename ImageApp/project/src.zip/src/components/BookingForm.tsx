import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Phone } from 'lucide-react';
import { db } from '../lib/firebase';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { generateCalendarLinks } from '../lib/calendar';
import { validatePhoneNumber, formatPhone } from '../utils/booking';
import Calendar from './Calendar';
import { useSettings } from '../hooks/useSettings';
import html2canvas from 'html2canvas';
import TicketCard from './TicketCard';
import { createRoot } from 'react-dom/client';
import TicketStamp from './animations/TicketStamp';

/* ---------------------- Zod schema ---------------------- */
const createBookingSchema = (serviceTypes: string[]) =>
  z.object({
    firstName: z.string().min(2, 'Nome richiesto'),
    lastName: z.string().min(2, 'Cognome richiesto'),
    email: z.string().email('Email non valida'),
    phone: z.string().min(9, 'Numero di telefono non valido').max(10, 'Numero di telefono non valido'),
    service: z.enum(serviceTypes as [string, ...string[]], {
      required_error: 'Seleziona un tipo di servizio',
    }),
    notes: z.string().optional(),
  });

type BookingFormData = z.infer<ReturnType<typeof createBookingSchema>>;

/* ---------------------- Tipi personalizzati ---------------------- */
interface BookingData extends BookingFormData {
  ticketNumber: string;
  calendarLinks: { google: string; ical: string };
}

interface BookingFormProps {
  existingBookings?: any[];
}

/* ---------------------- Componente BookingForm ---------------------- */
const BookingForm: React.FC<BookingFormProps> = ({ existingBookings = [] }) => {
  const { settings, loading: settingsLoading } = useSettings();
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [selectedTime, setSelectedTime] = useState<string>('');
  const [selectedService, setSelectedService] = useState<string>('');
  const [showTicket, setShowTicket] = useState(false);
  const [bookingData, setBookingData] = useState<BookingData | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [bookingComplete, setBookingComplete] = useState(false);
  const [confirmedDate, setConfirmedDate] = useState<Date | null>(null);
  const [confirmedTime, setConfirmedTime] = useState<string>('');

  // Otteniamo i serviceTypes abilitati
  const enabledServiceTypes =
    settings?.serviceTypes.filter((s) => s.enabled).map((s) => s.id) || [];

  // Creiamo lo schema di validazione con zod
  const schema = createBookingSchema(enabledServiceTypes);

  // Hook di React Hook Form
  const {
    register,
    handleSubmit: handleFormSubmit,
    formState: { errors },
    reset,
    setValue,
  } = useForm<BookingFormData>({
    resolver: zodResolver(schema),
  });

  /* ---------------------- Impostazione servizio di default ---------------------- */
  useEffect(() => {
    if (settings?.serviceTypes && !selectedService) {
      const enabledServices = settings.serviceTypes.filter((s) => s.enabled);
      if (enabledServices.length > 0) {
        const firstService = enabledServices[0];
        setSelectedService(firstService.id);
        setValue('service', firstService.id);
      }
    }
  }, [settings?.serviceTypes, selectedService, setValue]);

  /* ---------------------- Utility per generare il ticketNumber ---------------------- */
  const generateTicketNumber = () => {
    return `CNC-${Math.random().toString(36).substr(2, 6).toUpperCase()}`;
  };

  /* ---------------------- Selezione slot (data + ora) in locale ---------------------- */
  const handleSlotSelect = (date: Date, time: string) => {
    // Creiamo la data in formato locale, SENZA usare Date.UTC
    const localDate = new Date(
      date.getFullYear(),
      date.getMonth(),
      date.getDate()
    );
    setSelectedDate(localDate);
    setSelectedTime(time);
  };

  /* ---------------------- Animazione timbro biglietto ---------------------- */
  const showTicketStampAnimation = async (ticketNumber: string) => {
    return new Promise<void>((resolve) => {
      const stampContainer = document.createElement('div');
      document.body.appendChild(stampContainer);

      const root = createRoot(stampContainer);
      root.render(
        <TicketStamp
          type={settings?.ticketTemplate?.type || 'classic'}
          ticketNumber={ticketNumber}
          onComplete={() => {
            root.unmount();
            document.body.removeChild(stampContainer);
            resolve();
          }}
        />
      );
    });
  };

  /* ---------------------- Submit del form ---------------------- */
  const onSubmit = async (data: BookingFormData) => {
    if (!selectedDate || !selectedTime || !settings) {
      setError('Seleziona data e ora per la prenotazione');
      return;
    }

    // Costruiamo la data+ora di inizio prenotazione in locale
    const [hours, minutes] = selectedTime.split(':').map(Number);
    const bookingStart = new Date(
      selectedDate.getFullYear(),
      selectedDate.getMonth(),
      selectedDate.getDate(),
      hours,
      minutes,
      0, // secondi
      0  // millisecondi
    );

    // Controllo: se bookingStart è già nel passato, blocchiamo la prenotazione
    if (bookingStart < new Date()) {
      setError('Non è possibile prenotare per un orario già passato');
      return;
    }

    // Validiamo il numero di telefono
    if (!validatePhoneNumber(data.phone)) {
      setError('Inserisci un numero di telefono italiano valido (9-10 cifre)');
      return;
    }

    setIsSubmitting(true);
    setError(null);

    try {
      const formattedPhone = formatPhone(data.phone);
      const ticketNumber = generateTicketNumber();

      // Durata dell'evento, in base alle impostazioni (bookingIntervals in minuti)
      const endTime = new Date(bookingStart.getTime() + settings.bookingIntervals * 60000);

      const serviceName =
        settings.serviceTypes.find((s) => s.id === data.service)?.name ||
        'Servizio Fotografico';

      // Genera i link per il calendario
      const calendarLinksRaw = generateCalendarLinks({
        summary: settings.eventName,
        description: `${serviceName}\nPrenotazione: ${ticketNumber}\nNome: ${data.firstName} ${data.lastName}`,
        startDateTime: bookingStart.toISOString(),
        endDateTime: endTime.toISOString(),
      });
      // Adattiamo la forma per soddisfare { google, ical }
      const calendarLinks = {
        google: calendarLinksRaw.googleCalendar,
        ical: calendarLinksRaw.googleCalendar
      };

      // Salviamo la prenotazione su Firestore
      await addDoc(collection(db, 'bookings'), {
        firstName: data.firstName,
        lastName: data.lastName,
        email: data.email,
        phone: formattedPhone,
        service_type: data.service,
        booking_date: bookingStart.toISOString().split('T')[0], // Salviamo la data in formato YYYY-MM-DD
        booking_time: selectedTime, // Salviamo l'ora come stringa
        ticket_number: ticketNumber,
        notes: data.notes,
        status: 'pending',
        created_at: serverTimestamp(),
      });

      // Salviamo data e ora confermate per la visualizzazione del ticket
      setConfirmedDate(bookingStart);
      setConfirmedTime(selectedTime);

      // Salviamo i dati della prenotazione (comprese le info per il calendario)
      setBookingData({
        ...data,
        ticketNumber,
        calendarLinks,
      });

      // Se abilitato, mostriamo l'animazione del timbro
      if (settings.ticketTemplate?.enabled) {
        await showTicketStampAnimation(ticketNumber);
      }

      setBookingComplete(true);
      setShowTicket(true);

      // Resettiamo il form
      reset();
      setSelectedDate(null);
      setSelectedTime('');
    } catch (err: any) {
      console.error('Error creating booking:', err);
      setError(err.message || 'Errore durante la prenotazione. Riprova più tardi.');
    } finally {
      setIsSubmitting(false);
    }
  };

  /* ---------------------- Render del componente ---------------------- */
  if (settingsLoading) {
    return <div className="text-center text-white">Caricamento...</div>;
  }

  if (bookingComplete && showTicket && bookingData && bookingData.ticketNumber && settings && confirmedDate) {
    return (
      <div className="max-w-3xl mx-auto p-4">
        <TicketCard
          bookingData={bookingData}
          settings={settings}
          selectedDate={confirmedDate}
          selectedTime={confirmedTime}
          onDownload={() => {
            const ticketElement = document.getElementById('ticket');
            if (ticketElement) {
              html2canvas(ticketElement, {
                scale: 2,
                backgroundColor: '#f8f4e9',
                logging: false,
                useCORS: true,
                allowTaint: true,
                onclone: (clonedDoc) => {
                  const clonedTicket = clonedDoc.getElementById('ticket');
                  if (clonedTicket) {
                    clonedTicket.style.display = 'block';
                    clonedTicket.style.width = '800px';
                    clonedTicket.style.height = 'auto';
                  }
                },
              }).then((canvas) => {
                const link = document.createElement('a');
                link.download = `biglietto-${bookingData.ticketNumber}.jpg`;
                link.href = canvas.toDataURL('image/jpeg', 0.95);
                link.click();
              });
            }
          }}
        />
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-8">
      {/* Colonna sinistra: selezione servizio + Calendario */}
      <div>
        <div className="mb-4">
          <select
            {...register('service')}
            value={selectedService}
            onChange={(e) => {
              setSelectedService(e.target.value);
              setValue('service', e.target.value);
            }}
            className="w-full p-2 rounded bg-gray-800 text-white border border-gray-700 focus:border-[--theater-gold] outline-none"
          >
            <option value="">Seleziona servizio</option>
            {settings?.serviceTypes
              .filter((service) => service.enabled)
              .map((service) => (
                <option key={service.id} value={service.id}>
                  {service.name}
                </option>
              ))}
          </select>
          {errors.service && <p className="text-red-500 mt-1">{errors.service.message}</p>}
        </div>

        <Calendar
          onSlotSelect={handleSlotSelect}
          selectedDate={selectedDate}
          selectedTime={selectedTime}
          selectedService={selectedService}
        />
      </div>

      {/* Colonna destra: form di inserimento dati */}
      <form onSubmit={handleFormSubmit(onSubmit)} className="space-y-6">
        {error && (
          <div className="bg-red-500 text-white p-4 rounded mb-4">
            {error}
          </div>
        )}

        {selectedDate && selectedTime && (
          <div className="bg-green-100 text-green-800 p-4 rounded mb-4">
            Hai selezionato: {selectedDate.toLocaleDateString()} alle {selectedTime}
          </div>
        )}

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-white mb-2">Nome</label>
            <input
              {...register('firstName')}
              className="w-full p-2 rounded bg-gray-800 text-white border border-gray-700 focus:border-[--theater-gold] outline-none"
              placeholder="Mario"
            />
            {errors.firstName && <p className="text-red-500 mt-1">{errors.firstName.message}</p>}
          </div>

          <div>
            <label className="block text-white mb-2">Cognome</label>
            <input
              {...register('lastName')}
              className="w-full p-2 rounded bg-gray-800 text-white border border-gray-700 focus:border-[--theater-gold] outline-none"
              placeholder="Rossi"
            />
            {errors.lastName && <p className="text-red-500 mt-1">{errors.lastName.message}</p>}
          </div>
        </div>

        <div>
          <label className="block text-white mb-2">Email</label>
          <input
            type="email"
            {...register('email')}
            className="w-full p-2 rounded bg-gray-800 text-white border border-gray-700 focus:border-[--theater-gold] outline-none"
            placeholder="mario.rossi@example.com"
          />
          {errors.email && <p className="text-red-500 mt-1">{errors.email.message}</p>}
        </div>

        <div>
          <label className="block text-white mb-2">Telefono</label>
          <div className="relative">
            <Phone className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
            <input
              type="tel"
              {...register('phone')}
              className="w-full pl-10 p-2 rounded bg-gray-800 text-white border border-gray-700 focus:border-[--theater-gold] outline-none"
              placeholder="Inserisci il numero senza prefisso (es: 3401234567)"
            />
          </div>
          {errors.phone && <p className="text-red-500 mt-1">{errors.phone.message}</p>}
          <p className="text-sm text-gray-400 mt-1">
            Inserisci solo le cifre del numero senza prefisso internazionale
          </p>
        </div>

        <div>
          <label className="block text-white mb-2">Note (opzionale)</label>
          <textarea
            {...register('notes')}
            rows={3}
            className="w-full p-2 rounded bg-gray-800 text-white border border-gray-700 focus:border-[--theater-gold] outline-none"
          />
        </div>

        <button
          type="submit"
          disabled={isSubmitting || !selectedDate || !selectedTime}
          className="w-full bg-[--theater-red] text-white py-3 px-6 rounded-full hover:bg-red-700 transition-colors text-lg font-bold disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isSubmitting ? 'Conferma in corso...' : 'Conferma Prenotazione'}
        </button>
      </form>
    </div>
  );
};

export default BookingForm;
